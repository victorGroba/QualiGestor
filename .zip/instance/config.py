DEBUG = True
SECRET_KEY = 'sua_chave_super_secreta'
SQLALCHEMY_DATABASE_URI = 'sqlite:///meubanco.db'
SQLALCHEMY_TRACK_MODIFICATIONS = False
