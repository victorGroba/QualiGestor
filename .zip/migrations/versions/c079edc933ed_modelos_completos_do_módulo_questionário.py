"""Modelos completos do módulo Questionário

Revision ID: c079edc933ed
Revises: a48c1788dc93
Create Date: 2025-05-29 11:12:41.012564
"""
from alembic import op
import sqlalchemy as sa

# revision identifiers, used by Alembic.
revision = 'c079edc933ed'
down_revision = 'a48c1788dc93'
branch_labels = None
depends_on = None

def upgrade():
    op.create_table('configuracao_email',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('enviar_email', sa.Boolean(), nullable=True),
        sa.Column('configurar_no_final', sa.Boolean(), nullable=True),
        sa.Column('exibir_emails_anteriores', sa.Boolean(), nullable=True),
        sa.Column('idioma', sa.String(length=50), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_table('configuracao_nota',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('calcular_nota', sa.Boolean(), nullable=True),
        sa.Column('ocultar_nota', sa.Boolean(), nullable=True),
        sa.Column('base_calculo', sa.Integer(), nullable=True),
        sa.Column('casas_decimais', sa.Integer(), nullable=True),
        sa.Column('modo_configuracao', sa.String(length=50), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_table('configuracao_relatorio',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('exibir_nota_anterior', sa.Boolean(), nullable=True),
        sa.Column('exibir_tabela_resumo', sa.Boolean(), nullable=True),
        sa.Column('exibir_limites_aceitaveis', sa.Boolean(), nullable=True),
        sa.Column('omitir_data_hora', sa.Boolean(), nullable=True),
        sa.Column('exibir_omitidas', sa.Boolean(), nullable=True),
        sa.Column('gerar_relatorio_nc', sa.Boolean(), nullable=True),
        sa.Column('modo_exibicao_nota', sa.String(length=50), nullable=True),
        sa.Column('tipo_agrupamento', sa.String(length=50), nullable=True),
        sa.Column('cor_observacoes', sa.String(length=50), nullable=True),
        sa.Column('cor_relatorio', sa.String(length=50), nullable=True),
        sa.Column('logotipo_cabecalho', sa.String(length=255), nullable=True),
        sa.Column('logotipo_rodape', sa.String(length=255), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_table('grupo_questionario',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('questionario_id', sa.Integer(), nullable=True),
        sa.Column('grupo_id', sa.Integer(), nullable=True),
        sa.ForeignKeyConstraint(['questionario_id'], ['questionario.id']),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_table('usuario_autorizado',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('questionario_id', sa.Integer(), nullable=True),
        sa.Column('nome', sa.String(length=100), nullable=True),
        sa.Column('email', sa.String(length=120), nullable=True),
        sa.ForeignKeyConstraint(['questionario_id'], ['questionario.id']),
        sa.PrimaryKeyConstraint('id')
    )
    with op.batch_alter_table('questionario', schema=None) as batch_op:
        batch_op.add_column(sa.Column('modo', sa.String(length=50), nullable=True))
        batch_op.add_column(sa.Column('documento_referencia', sa.String(length=255), nullable=True))
        batch_op.add_column(sa.Column('criado_em', sa.DateTime(), nullable=True))
        batch_op.add_column(sa.Column('configuracao_nota_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('configuracao_relatorio_id', sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column('configuracao_email_id', sa.Integer(), nullable=True))
        batch_op.create_foreign_key('fk_questionario_config_relatorio', 'configuracao_relatorio', ['configuracao_relatorio_id'], ['id'])
        batch_op.create_foreign_key('fk_questionario_config_nota', 'configuracao_nota', ['configuracao_nota_id'], ['id'])
        batch_op.create_foreign_key('fk_questionario_config_email', 'configuracao_email', ['configuracao_email_id'], ['id'])
        batch_op.drop_column('data_atualizacao')

def downgrade():
    with op.batch_alter_table('questionario', schema=None) as batch_op:
        batch_op.add_column(sa.Column('data_atualizacao', sa.DateTime(), nullable=True))
        batch_op.drop_constraint('fk_questionario_config_email', type_='foreignkey')
        batch_op.drop_constraint('fk_questionario_config_nota', type_='foreignkey')
        batch_op.drop_constraint('fk_questionario_config_relatorio', type_='foreignkey')
        batch_op.drop_column('configuracao_email_id')
        batch_op.drop_column('configuracao_relatorio_id')
        batch_op.drop_column('configuracao_nota_id')
        batch_op.drop_column('criado_em')
        batch_op.drop_column('documento_referencia')
        batch_op.drop_column('modo')

    op.drop_table('usuario_autorizado')
    op.drop_table('grupo_questionario')
    op.drop_table('configuracao_relatorio')
    op.drop_table('configuracao_nota')
    op.drop_table('configuracao_email')
