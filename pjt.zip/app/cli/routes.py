from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import current_user, login_required
from datetime import datetime
from ..models import db,Formulario, Pergunta, Auditoria, Loja, Cliente, OpcaoPergunta, Avaliado, CampoPersonalizado, CampoPersonalizadoValor

cli_bp = Blueprint('cli', __name__, template_folder='templates')


@cli_bp.route('/')
@login_required
def index():
    formularios = Formulario.query.all()
    return render_template('cli/index.html', formularios=formularios)

@cli_bp.route('/formulario/novo', methods=['GET', 'POST'])
@login_required
def criar_formulario():
    clientes = Cliente.query.all()
    lojas = Loja.query.all()
    return render_template('cli/criar_formulario.html', clientes=clientes, lojas=lojas)

@cli_bp.route('/formulario/salvar', methods=['POST'])
@login_required
def salvar_formulario():
    nome = request.form.get('nome_formulario')
    cliente_id = request.form.get('cliente_id')
    loja_id = request.form.get('loja_id')

    if not nome:
        flash("Nome do formulário é obrigatório.", "danger")
        return redirect(url_for('cli.criar_formulario'))

    novo_formulario = Formulario(nome=nome, cliente_id=cliente_id, loja_id=loja_id)
    db.session.add(novo_formulario)
    db.session.flush()

    perguntas_keys = [k for k in request.form if k.startswith('perguntas[') and k.endswith('][texto]')]
    perguntas_processadas = set()

    for key in perguntas_keys:
        pergunta_idx = key.split('[')[1].split(']')[0]
        if pergunta_idx in perguntas_processadas:
            continue
        perguntas_processadas.add(pergunta_idx)

        texto = request.form.get(f'perguntas[{pergunta_idx}][texto]')
        tipo = request.form.get(f'perguntas[{pergunta_idx}][tipo]')
        obrigatoria = request.form.get(f'perguntas[{pergunta_idx}][obrigatoria]') == 'on'

        nova_pergunta = Pergunta(
            texto=texto,
            tipo_resposta=tipo,
            obrigatoria=obrigatoria,
            formulario_id=novo_formulario.id
        )
        db.session.add(nova_pergunta)

    db.session.commit()
    flash("Formulário salvo com sucesso!", "success")
    return redirect(url_for('cli.visualizar_formulario', formulario_id=novo_formulario.id))

@cli_bp.route('/formulario/<int:formulario_id>')
@login_required
def visualizar_formulario(formulario_id):
    formulario = Formulario.query.get_or_404(formulario_id)
    return render_template('cli/formulario_visualizacao.html', formulario=formulario)

@cli_bp.route('/checklist/aplicar/<int:formulario_id>', methods=['GET', 'POST'])
@login_required
def aplicar_checklist(formulario_id):
    formulario = Formulario.query.get_or_404(formulario_id)
    perguntas = formulario.perguntas
    lojas = Loja.query.all()

    if request.method == 'POST':
        loja_id = request.form.get('loja_id')
        if not loja_id:
            flash('Selecione a loja.', 'danger')
            return render_template('cli/aplicar_checklist.html', formulario=formulario, lojas=lojas)

        nova_checklist = Auditoria(
            data=datetime.utcnow(),
            usuario_id=current_user.id,
            loja_id=loja_id,
            formulario_id=formulario.id
        )
        db.session.add(nova_checklist)
        db.session.flush()

        for pergunta in perguntas:
            valor = request.form.get(f'pergunta_{pergunta.id}', '').strip()
            if pergunta.obrigatoria and not valor:
                flash(f'A pergunta \"{pergunta.texto}\" é obrigatória.', 'warning')
                return render_template('cli/aplicar_checklist.html', formulario=formulario, lojas=lojas)

            # Aqui você pode salvar a resposta em uma nova tabela se desejar criar esse modelo
            # Exemplo:
            # resposta = Resposta(pergunta_id=pergunta.id, auditoria_id=nova_checklist.id, valor=valor)
            # db.session.add(resposta)

        db.session.commit()
        flash('Checklist salvo com sucesso!', 'success')
        return redirect(url_for('cli.index'))

    return render_template('cli/aplicar_checklist.html', formulario=formulario, lojas=lojas)

@cli_bp.route('/checklists')
@login_required
def listar_checklists():
    checklists = Auditoria.query.order_by(Auditoria.data.desc()).all()
    return render_template('cli/listar_checklists.html', checklists=checklists)

@cli_bp.route('/checklist/<int:checklist_id>')
@login_required
def ver_checklist(checklist_id):
    checklist = Auditoria.query.get_or_404(checklist_id)
    return render_template('cli/ver_checklist.html', checklist=checklist)




@cli_bp.route('/avaliado/novo', methods=['GET', 'POST'])
@login_required
def cadastrar_avaliado():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        endereco = request.form.get('endereco')
        idioma = request.form.get('idioma')
        cliente_id = current_user.cliente_id  # ou algum valor padrão

        if not nome:
            flash("Nome do avaliado é obrigatório", "danger")
            return redirect(url_for('cli.cadastrar_avaliado'))

        novo_avaliado = Avaliado(
            nome=nome,
            email=email,
            endereco=endereco,
            idioma=idioma,
            cliente_id=cliente_id
        )
        db.session.add(novo_avaliado)
        db.session.commit()
        flash("Avaliado cadastrado com sucesso!", "success")
        return redirect(url_for('cli.index'))

    return render_template('cli/cadastrar_avaliado.html')
