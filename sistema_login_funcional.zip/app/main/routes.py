
from flask import Blueprint, render_template, session, redirect, url_for, flash

from ..utils.decorators import login_required

main_bp = Blueprint('main', __name__, template_folder='templates')

@main_bp.route('/')
def home():
    if 'usuario_id' not in session:
        flash('Você precisa estar logado para acessar o sistema.', 'warning')
        return redirect(url_for('auth.login'))

    return render_template('main/home.html')
