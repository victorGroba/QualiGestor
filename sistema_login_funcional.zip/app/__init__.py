import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from dotenv import load_dotenv
from flask_login import LoginManager

# Carrega variáveis do .env
load_dotenv()

# Instância global do banco e do login manager
db = SQLAlchemy()
login_manager = LoginManager()

# Configura onde redirecionar quando não logado
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'warning'

def create_app():
    app = Flask(__name__)

    # Configurações principais
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///banco.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Inicializa extensões
    db.init_app(app)
    login_manager.init_app(app)

    # Registro dos blueprints
    from .auth.routes import auth_bp
    from .cli.routes import cli_bp
    from .main.routes import main_bp
    from .laudos.routes import laudos_bp
    from .panorama.routes import panorama_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(cli_bp, url_prefix='/cli')
    app.register_blueprint(main_bp)
    app.register_blueprint(laudos_bp)
    app.register_blueprint(panorama_bp, url_prefix='/panorama')

    return app

__all__ = ['db', 'create_app', 'login_manager']
